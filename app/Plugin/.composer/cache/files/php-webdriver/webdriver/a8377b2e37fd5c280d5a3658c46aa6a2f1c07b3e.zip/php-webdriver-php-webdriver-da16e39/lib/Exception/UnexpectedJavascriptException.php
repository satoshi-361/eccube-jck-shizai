<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Use Facebook\WebDriver\Exception\JavascriptErrorException
 */
class UnexpectedJavascriptException extends JavascriptErrorException
{
}
