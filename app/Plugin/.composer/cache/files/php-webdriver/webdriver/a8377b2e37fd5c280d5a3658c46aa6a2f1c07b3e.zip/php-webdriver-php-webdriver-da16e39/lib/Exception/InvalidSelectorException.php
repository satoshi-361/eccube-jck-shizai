<?php

namespace Facebook\WebDriver\Exception;

/**
 * Argument was an invalid selector.
 */
class InvalidSelectorException extends WebDriverException
{
}
